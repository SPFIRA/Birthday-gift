const CONTENT = {
  name: "My Favorite Person",
  date: "YOUR SPECIAL DAY",
  subtitle: "I made you something you can't unwrap.",
  letterDate: "For the day the world got a little brighter",
  letter: `Write your real birthday message here.

Tell her what you appreciate about her. Add your inside jokes. Mention the tiny moments that nobody else would understand.

This page is yours, so make this part sound like you, not like a greeting-card company with a marketing department.`,
  signature: "your name",
  secretTitle: "If you ever forget...",
  secret: `You are loved in the quiet moments too.

Not just on birthdays. Not just when everything is perfect.

Keep this little page for the days when you need a reminder.`,
  finalMessage: "Happy birthday. I hope this year gives you more reasons to smile than you can count.",
  memories: [
    { image: "./assets/photos/memory-01.webp", title: "A day I kept", text: "replace this caption" },
    { image: "./assets/photos/memory-02.webp", title: "One of my favorites", text: "replace this caption" },
    { image: "./assets/photos/memory-03.webp", title: "That little moment", text: "replace this caption" },
    { image: "./assets/photos/memory-04.webp", title: "Still makes me smile", text: "replace this caption" }
  ],
  timeline: [
    { year: "01", title: "The beginning", text: "Write how you first met, first talked, or the first moment that mattered." },
    { year: "02", title: "A favorite memory", text: "Write about a tiny moment that became a big memory." },
    { year: "03", title: "Right now", text: "Write what you appreciate about who she is today." },
    { year: "∞", title: "Next chapter", text: "Write something you hope you get to experience together." }
  ]
};

const $ = s => document.querySelector(s);
const setText = (s,v) => { const e=$(s); if(e) e.textContent=v; };

setText("#herName", CONTENT.name);
setText("#heroSubtitle", CONTENT.subtitle);
setText("#dateLabel", CONTENT.date);
setText("#letterDate", CONTENT.letterDate);
setText("#letterName", CONTENT.name);
$("#letterBody").textContent = CONTENT.letter;
setText("#signature", CONTENT.signature);
setText("#secretTitle", CONTENT.secretTitle);
$("#secretMessage").textContent = CONTENT.secret;
setText("#secretSign", CONTENT.signature);
setText("#finalMessage", CONTENT.finalMessage);

const grid = $("#memoryGrid");
CONTENT.memories.forEach((m,i)=>{
  const card=document.createElement("article");
  card.className="memory-card";
  card.style.setProperty("--r", `${i%2===0 ? -1.1 : 1.2}deg`);
  card.innerHTML=`<img src="${m.image}" alt="${m.title}" loading="lazy"><div class="memory-caption">${m.title}<br><span>${m.text}</span></div>`;
  grid.appendChild(card);
});
const timeline=$("#timelineList");
CONTENT.timeline.forEach(t=>{
  const item=document.createElement("article");
  item.className="timeline-item";
  item.innerHTML=`<div class="year">${t.year}</div><div><h3>${t.title}</h3><p>${t.text}</p></div>`;
  timeline.appendChild(item);
});

window.addEventListener("load",()=>setTimeout(()=>$("#loader").classList.add("hide"),700));

document.addEventListener("mousemove",e=>{
  const g=$(".cursor-glow");
  g.style.left=e.clientX+"px"; g.style.top=e.clientY+"px";
});

$("#beginBtn").onclick=()=>$("#cake").scrollIntoView({behavior:"smooth"});
$("#secretBtn").onclick=()=>{ $("#secretModal").classList.add("open"); $("#secretModal").setAttribute("aria-hidden","false"); };
$("#closeModal").onclick=()=>{ $("#secretModal").classList.remove("open"); $("#secretModal").setAttribute("aria-hidden","true"); };
$("#secretModal").onclick=e=>{if(e.target.id==="secretModal")$("#closeModal").click()};

let blowing=false, progress=0, timer;
const blow=()=>{
  if(blowing) return;
  blowing=true;
  timer=setInterval(()=>{
    progress=Math.min(100,progress+4);
    $("#blowProgress").style.width=progress+"%";
    if(progress>=100){
      clearInterval(timer);
      $("#blowBtn").textContent="WISH MADE ✦";
      $(".cake").classList.add("out");
      $("#wishText").textContent="The candles are out. Keep the wish to yourself.";
      $("#wishHint").textContent="Some things are better kept between you and the universe.";
      confetti(90);
      toast("A wish has been made ✦");
    }
  },45);
};
const stopBlow=()=>{clearInterval(timer);blowing=false};
$("#blowBtn").addEventListener("pointerdown",blow);
["pointerup","pointerleave","pointercancel"].forEach(x=>$("#blowBtn").addEventListener(x,stopBlow));

function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function confetti(n=50){
  const c=$("#confetti");
  for(let i=0;i<n;i++){
    const p=document.createElement("i");p.className="piece";
    p.style.left=Math.random()*100+"%";
    p.style.setProperty("--x",(Math.random()*300-150)+"px");
    p.style.animationDelay=Math.random()*.7+"s";
    p.style.opacity=.7+Math.random()*.3;
    p.style.background=["#f4b4c9","#fff2b8","#d86c9a","#ffffff","#a84c78"][Math.floor(Math.random()*5)];
    c.appendChild(p);setTimeout(()=>p.remove(),3800);
  }
}

const canvas=$("#stars"),ctx=canvas.getContext("2d"); let stars=[];
function resize(){canvas.width=innerWidth*devicePixelRatio;canvas.height=innerHeight*devicePixelRatio;ctx.scale(devicePixelRatio,devicePixelRatio);stars=Array.from({length:Math.min(170,innerWidth/6)},()=>({x:Math.random()*innerWidth,y:Math.random()*innerHeight,r:Math.random()*1.4+.2,a:Math.random(),s:Math.random()*.005+.001}))}
function animate(){ctx.clearRect(0,0,innerWidth,innerHeight);for(const s of stars){s.a+=s.s;if(s.a>1||s.a<.1)s.s*=-1;ctx.globalAlpha=s.a;ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill()}requestAnimationFrame(animate)}
addEventListener("resize",resize);resize();animate();

$("#fireBtn").onclick=()=>{
  confetti(150);
  for(let i=0;i<16;i++){
    setTimeout(()=>{
      const p=document.createElement("div");
      p.style.cssText=`position:fixed;left:${10+Math.random()*80}%;top:${25+Math.random()*45}%;width:4px;height:4px;border-radius:50%;background:#ffd4e1;box-shadow:0 0 18px #ffd4e1;z-index:56;animation:fire .8s ease-out forwards`;
      document.body.appendChild(p);setTimeout(()=>p.remove(),900);
    },i*90);
  }
  toast("The sky heard you ✦");
};
const style=document.createElement("style");
style.textContent="@keyframes fire{0%{transform:scale(.2);opacity:1}100%{transform:translateY(-80px) scale(7);opacity:0}}";
document.head.appendChild(style);
