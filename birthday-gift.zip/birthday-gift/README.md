# Birthday Gift Website ✦

A static, interactive birthday experience designed to deploy directly to **Vercel or GitHub Pages**.

## No build step
This project uses only:
- HTML
- CSS
- JavaScript
- local image files

There is no database, server, API key, npm install, or backend.

## 1. Customize it

Open:

`script.js`

At the top, edit the `CONTENT` object:

- `name`
- `date`
- `subtitle`
- `letter`
- `signature`
- `secret`
- `finalMessage`
- memory captions
- timeline text

## 2. Add your photos

Put your photos in:

`assets/photos/`

Then update the image names in `CONTENT.memories`.

The project already contains the four reference images you uploaded as:
- memory-01.webp
- memory-02.webp
- memory-03.webp
- memory-04.webp

Replace them with your own photos while keeping the filenames if you want zero code changes.

## 3. Deploy to Vercel

### Option A: GitHub
1. Create a new GitHub repository.
2. Upload the entire `birthday-gift` folder.
3. Open Vercel.
4. Import the GitHub repository.
5. Framework preset: **Other**
6. Build command: leave empty.
7. Output directory: `.` 
8. Deploy.

### Option B: Vercel CLI
From this folder:

```bash
npx vercel
```

Follow the prompts.

## 4. Important

The site is intentionally self-contained. It does not need a database or environment variables.

The "hold to blow" interaction is simulated in-browser, so it works without microphone permission.

The Google Fonts import is the only external resource in the CSS. If you want a completely offline version, remove the `@import` line and use the fallback fonts already listed.

## Suggested folder structure

birthday-gift/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
    └── photos/
        ├── memory-01.webp
        ├── memory-02.webp
        ├── memory-03.webp
        └── memory-04.webp
